# StockPulse

A single-file, production-ready stock website using TradingView widgets.

## Quick Start
1. Open `index.html` directly in a browser. (Best experience when hosted over HTTPS.)
2. Or drag-drop the folder into Netlify / Vercel, or push to a GitHub repo and enable Pages.

## Deploy to GitHub Pages
- Create a new repo and commit the files.
- In GitHub, go to Settings → Pages → Deploy from branch, select `main` and `/ (root)`.
- Your site will be live at `https://<your-username>.github.io/<repo>/`.

## Notes
- Widgets are provided by TradingView and require an internet connection.
- No API keys or server required.
